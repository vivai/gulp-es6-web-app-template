// @flow
import {hello} from './hello';

console.log(hello('World'));
